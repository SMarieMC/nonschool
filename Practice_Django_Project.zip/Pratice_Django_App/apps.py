from django.apps import AppConfig


class PraticeDjangoAppConfig(AppConfig):
    name = 'Pratice_Django_App'
