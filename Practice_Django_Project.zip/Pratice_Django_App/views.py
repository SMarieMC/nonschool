from django.shortcuts import render, HttpResponse

# Create your views here.
def index(request):
    return HttpResponse("<h1>This is my response!</h1>")

def person(request):
    return HttpResponse("This person is:")

def person_by_id(request, id):
    print(f"The id requested is {id}.")
    return HttpResponse(f"This person is {id}.")

def person_by_name(request, name):
    print(f"This name requested is {name}.")
    return HttpResponse(f"This person's name is {name}.")

def name(request):
    return HttpResponse("My name is Samantha.")

def sam(request):
    return HttpResponse("<h3>Sam</h3>")

def easy(request):
    return HttpResponse("It's getting easier to use Django.")