from django.urls import path     
from . import views
urlpatterns = [
    path('', views.index),
    path('person', views.person),
    path('name', views.name),
    path('sam', views.sam),
    path('person/<int:id>', views.person_by_id),
    path('person/<str:name>', views.person_by_name),
    path('easy', views.easy),
]