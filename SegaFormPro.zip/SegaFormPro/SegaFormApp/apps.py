from django.apps import AppConfig


class SegaformappConfig(AppConfig):
    name = 'SegaFormApp'
