from django.shortcuts import render, redirect
from .models import Game

# Create your views here.
def index(request):
    context = {
        "all_game":  Game.objects.all(),
    }
    return render(request, 'index.html', context)

def add_game(request):
    if request.method == "POST":
        game_name = request.POST['game_name']
        console_name = request.POST['console_name']
        description = request.POST['description']
        Game.objects.create(game_name=game_name, console_name=console_name, description=description)
    return redirect("/")